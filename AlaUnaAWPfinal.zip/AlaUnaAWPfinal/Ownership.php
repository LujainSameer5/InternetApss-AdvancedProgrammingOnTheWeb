<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ownership</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
    <link rel="stylesheet" href="Ownership.css">
    <link rel="stylesheet" href="menu.css">

</head>

<body>
    <?php
 require('loginAWP.php');
 ?>
    <div class="wrapper">
        <header class="page-header">
            <nav>
                <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png"
				width="120px" height="120px">
				</a>
                <ul>
                     <li class="dropdown" >
<a class="dropbtn"> New </a> 
<div class="dropdown-content">
    <a href="vintage-musical-instruments.php">vintage musical instruments</a>
    <a href="vintage-art-painting.php">vintage art painting</a>
    <a href="antiques.php">antiques</a>
    <a href="limited-musical-instruments.php">limited edition musical instruments</a>
    <a href="limited-art-painting.php">limited edition art painting</a>
    <a href="limited-pieces.php">limited edition pieces</a>

</div>
 </li>
                    <li>
                        <a href="Add-Pieces.php"> Add Piece  </a>
                    </li>
                    
                    <li>
                        <a href="about-us.php">About us  </a>
                    </li>
                </ul>
                <div class="cta-contact_2">
                    <button class="cta-contact">

                        <a href="like.php">
                            <img src="heart+like+love+valentine+icon-1320084901929215407_256.png"
                                width="20px" height="20px">
                        </a>
                    </button>

                    <button class="cta-contact">

                        <a href="cart.php">
                            <img src="cart.png" width="20px" height="20px">
                        </a>
                    </button>
                    <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
                    </button>
                    <?php
                    if($_SESSION['username']){
                    print"<a class='cta-contact' href='logout.php'> log out </a>";
                  }
                    ?>
                </div>
    </div>
    </nav>
    </header>
    </div>

    <div class="lightbox-blanket hidden">
        <div class="pop-up-container"></div>
    </div>
    <div class="random-background">
        <div class="itemlist">
            <div class="item-card">
                <div item-id-data="1">
                    <div class="item-image">
                        <img src="Certificate of Ownership Template 04_page-0001.jpg"
                            item-id-data="1" width="300px" height="300px" />
                    </div>
                    <div class="item-details-wrapper">
                        <div class="item-more-details" item-id-data="1"><i class="fa fa-ellipsis-h"></i></div>
                        <div>

                            <div class="item-title" item-id-data="3">
                                <a href="Certificate of Ownership Template 04_page-0001.jpg">Ownership
                                    Document </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="item-card">
                <div item-id-data="3">
                    <div class="item-image">
                        <img src="Certificate of Ownership Template 042_page-0001.jpg"
                            item-id-data="1" width="300px" height="300px" />
                    </div>
                    <div class="item-details-wrapper">
                        <div class="item-more-details" item-id-data="3"><i class="fa fa-ellipsis-h"></i></div>
                        <div>

                            <div class="item-title" item-id-data="3">
                                <a href="Certificate of Ownership Template 042_page-0001.jpg">Ownership
                                    Document </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

	<footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course</p>
      </div></footer> 
</body>

</html>