<!DOCTYPE html>

<html lang="en">



<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="nicepage.css" media="screen">

    <link rel="stylesheet" href="login.css">

    <link rel="stylesheet" href="menu.css">

    <script type="text/javaScript" src="login.js"></script>

    <title>ALA UNA</title>

    

    <style>

        header{

            margin-bottom: 200px;

        }


        form{
            block-size: 600%;
        }

        footer{



            margin-top: 300px;



        }

    </style>





</head>

<!-- 

sign in & up



https://codepen.io/THEORLAN2/pen/mPLPwj



-->

<body>

<?php

 include('loginAWP.php');

 ?>

  

  

  

  <div class="wrapper">

        <header class="page-header">

            <nav>

                <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png" width="120px"

                        height="120px">

                </a>

                <ul>

                    <li class="dropdown">

                        <a class="dropbtn"> New </a>

                        <div class="dropdown-content">

                        <a href="vintage-musical-instruments.php">vintage musical instruments</a>
  <a href="vintage-art-painting.php">vintage art painting</a>
  <a href="antiques.php">antiques</a>
  <a href="limited-musical-instruments.php">limited edition musical instruments</a>
  <a href="limited-art-painting.php">limited edition art painting</a>
  <a href="limited-pieces.php">limited edition pieces</a>



                        </div>

                    </li>

                    <li>

                        <a href="Add-Pieces.php"> Add Piece </a>

                    </li>



                    <li>

                        <a href="about-us.php">About us </a>

                    </li>

                </ul>

                <div class="cta-contact_2">

                    <button class="cta-contact">



                        <a href="like.php">

                            <img src="heart+like+love+valentine+icon-1320084901929215407_256.png" width="20px"

                                height="20px">

                        </a>

                    </button>



                    <button class="cta-contact">



                        <a href="cart.php">

                            <img src="cart.png" width="20px" height="20px">

                        </a>

                    </button>

                    

                    <button name=signUp class="cta-contact"><a href="login.php"> <a class="dropbtn"> <?php sign_in(); ?>  </a> </button>

                </div>

    </div>

    </nav>

    </header>





    <div class="cont_principal">

        <div class="cont_centrar">

            <div class="cont_login">

            
                <form method="POST" action=<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>>

                    <div class="cont_tabs_login">
					
                        <ul class='ul_tabs'>

                            <li>SIGN UP<span class="linea_bajo_nom"></span>
                            </li>

                        </ul>

                    </div>

                    <div class="cont_text_inputs">

                        <input type="text" class="input_form_sign d_block active_inp" placeholder="NAME" name="name_us" required />
                       

                        <input type="text" class="input_form_sign d_block active_inp" placeholder="EMAIL"name="emauil_us" required />
                            

                        <input type="password" class="input_form_sign d_block  active_inp" placeholder="PASSWORD"

                            name="pass_us" required />
                        <input type="password" class="input_form_sign d_block active_inp" placeholder="CONFIRM PASSWORD"

                            name="conf_pass_us" required /> 


                       <div class="input_form_sign d_block active_inp" style="margin-left: 20px; margin-bottom: 25px; margin-top: -15px; border-bottom: 1px #663535">

                            <p><input type="checkbox" name="terms_and_cons" required /> <label

                                    for="terms_and_cons">Accept Terms and Conditions.</label></p>
          </div>
						
						    

                    </div>

                    <div class="cont_btn">

                        <input type="submit" name="submit" class="btn_sign" href="profile.php" value="SIGN IN" >

                    </div>
                <div class="link_forgot_pass d_block" style="margin-left: 20px; margin-top: 0px; margin-bottom: 25px;" >
    
 Already have an account?<a href="signin.php">Sign in</a>



 

    </br>
    </br>
    </br>
              

</div> 

    <span class="link_forgot_pass d_block" style="margin-left: 5px; margin-top: 5px; margin-bottom: 0px; color: #FF0000;">

    <?php

    
$username = $_POST['name_us'];
$email = $_POST['emauil_us'];
$password = $_POST['pass_us'];
$passwordConfirm = $_POST['conf_pass_us'];

$data = $_POST;
if ($data['pass_us'] !== $data['conf_pass_us']) {
    $mssgeErrPass = "Password and Confirm password should match!";
    echo $mssgeErrPass; 

}
            ?>
              </span>

<span class="link_forgot_pass d_block" style="margin-left: 5px; margin-top: 5px; margin-bottom: 5px; color: #FF0000;">

<?php

$username = $_POST['name_us'];
$email = $_POST['emauil_us'];
$password = $_POST['pass_us'];
$passwordConfirm = $_POST['conf_pass_us'];


if (!preg_match ("/^[a-zA-z]*$/", $username) ) {  
   // die('Only alphabets and whitespace are allowed.');   
   $ErrMsg = "Only alphabets and whitespace are allowed.";  
            echo $ErrMsg;  
  }

        ?>
          </span>

<span class="link_forgot_pass d_block" style="margin-left: 5px; margin-top: 5px; margin-bottom: 5px; color: #FF0000;">

<?php


$username = $_POST['name_us'];
$email = $_POST['emauil_us'];
$password = $_POST['pass_us'];
$passwordConfirm = $_POST['conf_pass_us'];

//$data = $_POST;
$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  

// True because $a is empty
if (empty($email)) {
    echo " ";
  }
  

else if (!preg_match ($pattern, $email) ){ 
  //  die('Email is not valid.');   
    $ErrMsg = "Email is not valid.";  
          echo $ErrMsg; 
        }
    else
            {
echo " ";
            } 

        ?>
  </span>

</br>
</br>
</br>
                

</form>
            </div>

        </div>
    
    </div>

   

<!--
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa">

        <div class="u-clearfix u-sheet u-sheet-1">

            <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made

                with love by Umm Al-Qura University CS students in Internet applications course</p>

        </div>

    </footer>
-->


</body>





</html>