<!DOCTYPE html>

<html lang="en">



<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="nicepage.css" media="screen">

    <link rel="stylesheet" href="login.css">

    <link rel="stylesheet" href="menu.css">

    <script type="text/javaScript" src="login.js"></script> 

    <title>ALA UNA</title>

    

    <style>

        header{

            margin-bottom: 200px;

        }



        footer{



            margin-top: 300px;



        }

    </style>





</head>

<!-- 

sign in & up



https://codepen.io/THEORLAN2/pen/mPLPwj



-->

<body >

<?php

require('loginAWP.php');
if(isset($_COOKIE['emauil_us']) && isset($_COOKIE['pass_us'])){
    $id=$_COOKIE['emauil_us'];
    $pass=$_COOKIE['pass_us'];
}
else{
    $id="";
    $pass="";
}
 ?>

  <div class="wrapper">

        <header class="page-header">

            <nav>

                <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png" width="120px"

                        height="120px">

                </a>

                <ul>

                    <li class="dropdown">

                        <a class="dropbtn"> New </a>

                        <div class="dropdown-content">

                        <a href="vintage-musical-instruments.php">vintage musical instruments</a>
  <a href="vintage-art-painting.php">vintage art painting</a>
  <a href="antiques.php">antiques</a>
  <a href="limited-musical-instruments.php">limited edition musical instruments</a>
  <a href="limited-art-painting.php">limited edition art painting</a>
  <a href="limited-pieces.php">limited edition pieces</a>



                        </div>

                    </li>

                    <li>

                        <a href="Add-Pieces.php"> Add Piece </a>

                    </li>



                    <li>

                        <a href="about-us.php">About us </a>

                    </li>

                </ul>

                <div class="cta-contact_2">

                    <button class="cta-contact">



                        <a href="like.html">

                            <img src="heart+like+love+valentine+icon-1320084901929215407_256.png" width="20px"

                                height="20px">

                        </a>

                    </button>



                    <button class="cta-contact">



                        <a href="cart.php">

                            <img src="cart.png" width="20px" height="20px">

                        </a>

                    </button>

                    

                    

                    <button name=signUp class="cta-contact"><a href="login.php"> <a class="dropbtn"> <?php sign_in();  ?>  </a> </button>

                </div>

    </div>

    </nav>

    </header>





    <div class="cont_principal">

        <div class="cont_centrar">

            <div class="cont_login">
                
                <form method="POST" action="login.php">

                    <div class="cont_tabs_login">
					
                        <ul class='ul_tabs'>

                            <li>SIGN UP<span class="linea_bajo_nom"></span>

                            </li>

                        </ul>

                    </div>

                    <div class="cont_text_inputs">

                        

                        <input type="text" class="input_form_sign d_block active_inp" placeholder="EMAIL"

                            name="emauil_us" id="emauil_us" value="<?php echo $id;?>"required />



                        <input type="password" class="input_form_sign d_block  active_inp" placeholder="PASSWORD"

                            name="pass_us" id="pass_us" value="<?php echo $pass;?>" required />


								
                     
                     <input type="checkbox" name="remember"/> 
                     <label>Remember me</label>
                    </div>

                    <div class="cont_btn">

                        <input type="submit" name="submit2" class="btn_sign" href="profile.php" value="SIGN IN" >

                        

                    </div>



                </form>

            </div>



        </div>



    </div>


    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa">

        <div class="u-clearfix u-sheet u-sheet-1">

            <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made

                with love by Umm Al-Qura University CS students in Internet applications course</p>

        </div>

    </footer>



</body>





</html>