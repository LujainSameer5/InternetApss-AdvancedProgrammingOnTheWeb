<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>invoice</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="invoice.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link rel="stylesheet" href="menu.css">
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Site1",
		"logo": "images/a.jpg"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="invoice">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body">
    <?php
require('loginAWP.php');
?>

    <div class="wrapper">
      <header class="page-header">
          <nav>
              <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png"
      width="120px" height="120px">
      </a>
              <ul>
                   <li class="dropdown" >
<a class="dropbtn"> New </a> 
<div class="dropdown-content">
<a href="vintage-musical-instruments.php">vintage musical instruments</a>
              <a href="vintage-art-painting.php">vintage art painting</a>
              <a href="antiques.php">antiques</a>
              <a href="limited-musical-instruments.php">limited edition musical instruments</a>
              <a href="limited-art-painting.php">limited edition art painting</a>
              <a href="limited-pieces.php">limited edition pieces</a>

</div>
</li>
                  <li>
                      <a href="Add-Pieces.php"> Add Piece  </a>
                  </li>
                  
                  <li>
                      <a href="about-us.php">About us  </a>
                  </li>
              </ul>
              <div class="cta-contact_2">
                  <button class="cta-contact">

                      <a href="like.php">
                          <img src="heart+like+love+valentine+icon-1320084901929215407_256.png"
                              width="20px" height="20px">
                      </a>
                  </button>

                  <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }
          ?>
              </div>
  </div>
  </nav>
  </header>
  </div>

    <section class="u-align-center u-clearfix u-custom-color-1 u-section-1" id="sec-e825">
      <div class="u-clearfix u-sheet u-sheet-1">
        <a href="invoice.html" data-page-id="75224691" class="u-align-center u-border-1 u-border-active-palette-2-base u-border-hover-palette-1-base u-btn u-button-style u-custom-item u-none u-text-custom-color-3 u-btn-1"> &nbsp; <span class="u-icon u-icon-1"><svg class="u-svg-content" viewBox="0 0 512.017 512.017" x="0px" y="0px" style="width: 1em; height: 1em;"><g><g transform="translate(1 1)"><path style="fill:#FFB301;" d="M451.273,118.467v220.501L417.14,502.467h-307.2c-9.414-0.028-17.039-7.653-17.067-17.067V24.6    c0.028-9.414,7.652-17.039,17.067-17.067h230.4L451.273,118.467z"></path><path style="fill:#FEC108;" d="M425.673,118.467v220.501L391.54,502.467h-281.6c-9.414-0.028-17.039-7.653-17.067-17.067V24.6    c0.028-9.414,7.652-17.039,17.067-17.067h204.8L425.673,118.467z"></path><path style="fill:#283593;" d="M24.607,152.6h145.067c9.426,0,17.067,7.641,17.067,17.067v204.8    c0,9.426-7.641,17.067-17.067,17.067H24.607c-9.426,0-17.067-7.641-17.067-17.067v-204.8C7.54,160.241,15.181,152.6,24.607,152.6z    "></path><path style="fill:#3F51B5;" d="M24.607,152.6h119.467c9.426,0,17.067,7.641,17.067,17.067v204.8    c0,9.426-7.641,17.067-17.067,17.067H24.607c-9.426,0-17.067-7.641-17.067-17.067v-204.8C7.54,160.241,15.181,152.6,24.607,152.6z    "></path><path style="fill:#FF9801;" d="M340.34,7.533V101.4c0,9.426,7.641,17.067,17.067,17.067h93.867L340.34,7.533z"></path><g><path style="fill:#E91E63;" d="M118.473,255h25.6c4.713,0,8.533,3.821,8.533,8.533V280.6c0,4.713-3.821,8.533-8.533,8.533h-25.6     c-4.713,0-8.533-3.821-8.533-8.533v-17.067C109.94,258.821,113.76,255,118.473,255z"></path><path style="fill:#E91E63;" d="M118.473,323.267h25.6c4.713,0,8.533,3.82,8.533,8.533v17.067c0,4.713-3.821,8.533-8.533,8.533     h-25.6c-4.713,0-8.533-3.821-8.533-8.533V331.8C109.94,327.087,113.76,323.267,118.473,323.267z"></path>
</g><path style="fill:#FFFFFF;" d="M50.207,186.733h93.867c4.713,0,8.533,3.821,8.533,8.533v17.067c0,4.713-3.821,8.533-8.533,8.533    H50.207c-4.713,0-8.533-3.821-8.533-8.533v-17.067C41.673,190.554,45.494,186.733,50.207,186.733z"></path><path style="fill:#2E7D32;" d="M494.793,452.547c-15.852,34.759-52.861,54.762-90.624,48.981    c-7.751-1.223-15.301-3.491-22.443-6.741c-31.408-14.323-51.095-46.156-49.881-80.654c1.214-34.498,23.089-64.869,55.426-76.949    c32.337-12.081,68.767-3.492,92.303,21.76C503.11,384.195,509.117,421.139,494.793,452.547z"></path><path style="fill:#4CAF50;" d="M469.193,452.547c-11.963,26.3-36.444,44.741-65.024,48.981    c-7.751-1.223-15.301-3.491-22.443-6.741c-34.403-15.68-54.386-52.13-49.103-89.567c5.283-37.437,34.573-66.934,71.972-72.481    c26.385,4.147,49.318,20.383,61.994,43.893C479.266,400.142,480.229,428.224,469.193,452.547z"></path>
</g><g><path d="M25.607,401.067h145.067c14.132-0.015,25.585-11.468,25.6-25.6v-204.8c-0.015-14.132-11.468-25.585-25.6-25.6H25.607    c-14.132,0.015-25.585,11.468-25.6,25.6v204.8C0.022,389.599,11.474,401.051,25.607,401.067z M17.073,170.667    c0.006-4.71,3.823-8.527,8.533-8.533h145.067c4.71,0.006,8.527,3.823,8.533,8.533v204.8c-0.006,4.71-3.823,8.527-8.533,8.533    H25.607c-4.71-0.006-8.527-3.823-8.533-8.533V170.667z"></path><path d="M460.7,118.93c-0.047-0.747-0.194-1.485-0.437-2.193c-0.081-0.273-0.177-0.541-0.286-0.804    c-0.403-0.926-0.968-1.773-1.671-2.499L347.373,2.5c-0.727-0.703-1.574-1.269-2.502-1.672c-0.261-0.108-0.528-0.203-0.799-0.284    c-0.711-0.244-1.451-0.391-2.202-0.438C341.689,0.094,341.524,0,341.34,0h-230.4c-14.132,0.015-25.585,11.468-25.6,25.6v93.867    c0,4.713,3.821,8.533,8.533,8.533c4.713,0,8.533-3.821,8.533-8.533V25.6c0.006-4.71,3.823-8.527,8.533-8.533h221.867V102.4    c0.015,14.132,11.468,25.585,25.6,25.6h85.333v199.956c-44.027-12.54-90.674,8.547-110.346,49.883    c-19.673,41.336-6.62,90.835,30.878,117.095H110.94c-4.71-0.006-8.527-3.823-8.533-8.533v-59.733c0-4.713-3.821-8.533-8.533-8.533    c-4.713,0-8.533,3.82-8.533,8.533V486.4c0.015,14.132,11.468,25.585,25.6,25.6h306.763c0.105,0.001,0.211,0.017,0.317,0.017    c43.397,0.089,81.189-29.606,91.367-71.793c10.178-42.187-9.915-85.847-48.579-105.556V119.467    C460.807,119.281,460.712,119.114,460.7,118.93z M358.407,110.933c-4.71-0.006-8.527-3.823-8.533-8.533V29.133l81.8,81.8H358.407z     M488.032,450.038c-17.611,38.578-63.159,55.577-101.738,37.97c-38.579-17.607-55.583-63.153-37.98-101.734    c17.603-38.581,63.148-55.589,101.73-37.99C488.591,365.931,505.583,411.447,488.032,450.038z"></path><path d="M145.073,247.467h-25.6c-9.422,0.009-17.057,7.645-17.067,17.067V281.6c0.009,9.422,7.645,17.057,17.067,17.067h25.6    c9.422-0.009,17.057-7.645,17.067-17.067v-17.067C162.13,255.112,154.495,247.476,145.073,247.467z M145.073,281.6h-25.6v-17.067    h25.6V281.6z"></path><path d="M145.073,315.733h-25.6c-9.422,0.009-17.057,7.645-17.067,17.067v17.067c0.009,9.422,7.645,17.057,17.067,17.067h25.6    c9.422-0.009,17.057-7.645,17.067-17.067V332.8C162.13,323.378,154.495,315.743,145.073,315.733z M145.073,349.867h-25.6    l-0.012-17.067h25.612V349.867z"></path><path d="M42.673,281.6h8.533v8.533c0,4.713,3.821,8.533,8.533,8.533s8.533-3.821,8.533-8.533V281.6h8.533    c4.713,0,8.533-3.82,8.533-8.533s-3.82-8.533-8.533-8.533h-8.533V256c0-4.713-3.821-8.533-8.533-8.533s-8.533,3.821-8.533,8.533    v8.533h-8.533c-4.713,0-8.533,3.82-8.533,8.533S37.96,281.6,42.673,281.6z"></path><path d="M42.673,349.867h34.133c4.713,0,8.533-3.821,8.533-8.533s-3.82-8.533-8.533-8.533H42.673c-4.713,0-8.533,3.82-8.533,8.533    S37.96,349.867,42.673,349.867z"></path><path d="M221.873,179.2H418.14c4.713,0,8.533-3.821,8.533-8.533c0-4.713-3.82-8.533-8.533-8.533H221.873    c-4.713,0-8.533,3.821-8.533,8.533C213.34,175.38,217.16,179.2,221.873,179.2z"></path><path d="M221.873,230.4H418.14c4.713,0,8.533-3.821,8.533-8.533c0-4.713-3.82-8.533-8.533-8.533H221.873    c-4.713,0-8.533,3.821-8.533,8.533C213.34,226.579,217.16,230.4,221.873,230.4z"></path><path d="M221.873,281.6H418.14c4.713,0,8.533-3.82,8.533-8.533s-3.82-8.533-8.533-8.533H221.873c-4.713,0-8.533,3.82-8.533,8.533    S217.16,281.6,221.873,281.6z"></path><path d="M221.873,332.8H341.34c4.713,0,8.533-3.82,8.533-8.533s-3.821-8.533-8.533-8.533H221.873    c-4.713,0-8.533,3.821-8.533,8.533S217.16,332.8,221.873,332.8z"></path><path d="M51.207,230.4h93.867c9.422-0.009,17.057-7.645,17.067-17.067v-17.067c-0.009-9.422-7.645-17.057-17.067-17.067H51.207    c-9.422,0.009-17.057,7.645-17.067,17.067v17.067C34.149,222.755,41.785,230.391,51.207,230.4z M51.207,196.267h93.867    l0.012,17.067H51.207V196.267z"></path><path d="M446.044,377.601l1.133-2.484c1.956-4.287,0.066-9.348-4.221-11.304s-9.348-0.066-11.304,4.221l-1.132,2.481    c-5.396-1.248-11.008-1.234-16.397,0.044c-8.172,1.706-15.045,7.199-18.512,14.794c-3.466,7.595-3.112,16.386,0.953,23.677    c2.571,4.907,6.238,9.154,10.717,12.414l-9.625,21.093c-1.131-1.175-2.095-2.501-2.863-3.94c-1.536-2.718-1.779-5.98-0.663-8.896    c1.265-2.773,0.955-6.011-0.814-8.493c-1.769-2.482-4.728-3.833-7.762-3.542c-3.034,0.291-5.683,2.178-6.948,4.952    c-3.308,7.626-2.956,16.344,0.954,23.679c2.57,4.906,6.238,9.154,10.717,12.412l-1.133,2.484    c-1.271,2.774-0.963,6.016,0.806,8.502c1.77,2.486,4.732,3.837,7.769,3.545c3.037-0.293,5.687-2.185,6.95-4.963l1.09-2.389    c2.636,0.583,5.327,0.881,8.027,0.89c2.836,0.007,5.661-0.338,8.413-1.025c8.172-1.706,15.045-7.199,18.511-14.794    s3.112-16.386-0.953-23.677c-2.571-4.907-6.238-9.154-10.717-12.414l9.625-21.093c1.131,1.175,2.095,2.501,2.862,3.94    c1.536,2.718,1.779,5.98,0.663,8.896c-1.271,2.774-0.963,6.016,0.806,8.502c1.77,2.486,4.732,3.837,7.769,3.545    c3.037-0.293,5.687-2.185,6.949-4.963c3.308-7.626,2.956-16.344-0.954-23.679C454.19,385.106,450.523,380.859,446.044,377.601z     M411.798,401.333c-1.728-2.657-1.978-6.013-0.663-8.896s4.015-4.894,7.154-5.329c1.59-0.365,3.222-0.507,4.851-0.421    l-8.48,18.584C413.53,404.096,412.567,402.771,411.798,401.333L411.798,401.333z M424.523,434.975    c1.728,2.657,1.978,6.013,0.662,8.896s-4.015,4.894-7.154,5.329c-1.59,0.363-3.222,0.504-4.85,0.419l8.479-18.582    C422.791,432.212,423.754,433.537,424.523,434.975L424.523,434.975z"></path>
</g>
</g></svg><img></span>&nbsp;My invoices
        </a>
        <div class="u-expanded-width u-table u-table-responsive u-table-1">
          <table class="u-table-entity u-table-entity-1">
            <colgroup>
              <col width="33.3%">
              <col width="32.1%">
              <col width="34.599999999999994%">
            </colgroup>
            <thead class="u-black u-table-header u-table-header-1">
              <tr style="height: 29px;">
                <th class="u-border-1 u-border-custom-color-3 u-custom-color-3 u-table-cell u-table-cell-1">Price</th>
                <th class="u-border-1 u-border-black u-custom-color-3 u-table-cell u-table-cell-2">Date</th>
                <th class="u-border-1 u-border-black u-custom-color-3 u-table-cell u-table-cell-3">Invoice Number</th>
              </tr>
            </thead>
            <tbody class="u-table-body">
              <tr style="height: 96px;">
                <td class="u-border-1 u-border-grey-30 u-table-cell u-table-cell-4">450000000$</td>
                <td class="u-border-1 u-border-grey-30 u-table-cell u-table-cell-5">12/2/2021</td>
                <td class="u-border-1 u-border-grey-30 u-table-cell u-table-cell-6">1</td>
              </tr>
              <tr style="height: 40px;">
                <td class="u-border-1 u-border-grey-30 u-custom-color-3 u-table-cell u-table-cell-7">45000000$</td>
                <td class="u-border-1 u-border-grey-30 u-custom-color-3 u-table-cell u-table-cell-8"></td>
                <td class="u-border-1 u-border-grey-30 u-custom-color-3 u-table-cell u-table-cell-9">Total</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa"><div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course</p>
    </div></footer>
  </body>
</html>