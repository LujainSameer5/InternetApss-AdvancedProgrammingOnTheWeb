<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Charge the wallet</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Charge-the-wallet.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link rel="stylesheet" href="menu.css">
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Site1",
		"logo": "images/a.jpg"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Charge the wallet">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body">
  <?php
 require('loginAWP.php');
 ?>

    <div class="wrapper">
      <header class="page-header">
          <nav>
              <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png"
      width="120px" height="120px">
      </a>
              <ul>
                   <li class="dropdown" >
<a class="dropbtn"> New </a> 
<div class="dropdown-content">
<a href="vintage-musical-instruments.php">vintage musical instruments</a>
              <a href="vintage-art-painting.php">vintage art painting</a>
              <a href="antiques.php">antiques</a>
              <a href="limited-musical-instruments.php">limited edition musical instruments</a>
              <a href="limited-art-painting.php">limited edition art painting</a>
              <a href="limited-pieces.php">limited edition pieces</a>

</div>
</li>
                  <li>
                      <a href="Add-Pieces.php"> Add Piece  </a>
                  </li>
                  
                  <li>
                      <a href="about-us.php">About us  </a>
                  </li>
              </ul>
              <div class="cta-contact_2">
                  <button class="cta-contact">

                      <a href="like.php">
                          <img src="heart+like+love+valentine+icon-1320084901929215407_256.png"
                              width="20px" height="20px">
                      </a>
                  </button>

                  <button class="cta-contact">

                      <a href="cart.php">
                          <img src="cart.png" width="20px" height="20px">
                      </a>
                  </button>
                  <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }

          ?>
              </div>
  </div>
  </nav>
  </header>
  </div>


    <section class="u-align-center u-clearfix u-image u-section-1" id="sec-447c" data-image-width="928" data-image-height="1160">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h3 class="u-text u-text-custom-color-1 u-text-default u-text-1">&nbsp;Charge the wallet<span style="font-weight: 700;"></span>
        </h3>
        <div class="u-container-style u-custom-color-1 u-group u-radius-50 u-shape-round u-group-1">
          <div class="u-container-layout u-container-layout-1">
            <div class="u-form u-login-control u-form-1">
              <form action="#" method="POST" class="u-clearfix u-form-custom-backend u-form-spacing-35 u-form-vertical u-inner-form" source="custom" name="form-2" style="padding: 10px;">
                <div class="u-form-group u-form-name">
                  <label for="username-708d" class="u-form-control-hidden u-label"></label>
                  <input type="text" placeholder="Enter the card number" id="username-708d" name="username" class="u-grey-5 u-input u-input-rectangle" required="">
                </div>
                <div class="u-form-group u-form-password">
                  <label for="password-708d" class="u-form-control-hidden u-label"></label>
                  <input type="text" placeholder="Enter the  name the card holder" id="password-708d" name="password" class="u-grey-5 u-input u-input-rectangle" required="">
                </div>
                <div class="u-form-date u-form-group u-form-group-3">
                  <label for="date-2292" class="u-label">Expiry date</label>
                  <input type="date" placeholder="MM/DD/YYYY" id="date-2292" name="date" class="u-grey-5 u-input u-input-rectangle" required="">
                </div>
                <div class="u-form-group u-form-group-4">
                  <label for="text-79d7" class="u-form-control-hidden u-label"></label>
                  <input type="text" placeholder="Enter(CVV/CVC)" id="text-79d7" name="text" class="u-grey-5 u-input u-input-rectangle">
                </div>
                <div class="u-form-checkbox u-form-group">
                  <input type="checkbox" id="checkbox-708d" name="remember" value="On">
                  <label for="checkbox-708d" class="u-label">Remember me</label>
                </div>
                <div class="u-align-center u-form-group u-form-submit">
                  <a href="#" class="u-border-none u-btn u-btn-round u-btn-submit u-button-style u-custom-color-3 u-radius-17 u-btn-1">Add your card<br>
                  </a>
                  <input type="submit" value="submit" class="u-form-control-hidden">
                </div>
                <input type="hidden" value="" name="recaptchaResponse">
              </form>
            </div><span class="u-icon u-icon-circle u-text-palette-1-base u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 504 504" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-ca6d"></use></svg><svg class="u-svg-content" viewBox="0 0 504 504" x="0px" y="0px" id="svg-ca6d" style="enable-background:new 0 0 504 504;"><polygon style="fill:#3C58BF;" points="184.8,324.4 210.4,180.4 250.4,180.4 225.6,324.4 "></polygon><polygon style="fill:#293688;" points="184.8,324.4 217.6,180.4 250.4,180.4 225.6,324.4 "></polygon><path style="fill:#3C58BF;" d="M370.4,182c-8-3.2-20.8-6.4-36.8-6.4c-40,0-68.8,20-68.8,48.8c0,21.6,20,32.8,36,40  s20.8,12,20.8,18.4c0,9.6-12.8,14.4-24,14.4c-16,0-24.8-2.4-38.4-8l-5.6-2.4l-5.6,32.8c9.6,4,27.2,8,45.6,8  c42.4,0,70.4-20,70.4-50.4c0-16.8-10.4-29.6-34.4-40c-14.4-7.2-23.2-11.2-23.2-18.4c0-6.4,7.2-12.8,23.2-12.8  c13.6,0,23.2,2.4,30.4,5.6l4,1.6L370.4,182L370.4,182z"></path><path style="fill:#293688;" d="M370.4,182c-8-3.2-20.8-6.4-36.8-6.4c-40,0-61.6,20-61.6,48.8c0,21.6,12.8,32.8,28.8,40  s20.8,12,20.8,18.4c0,9.6-12.8,14.4-24,14.4c-16,0-24.8-2.4-38.4-8l-5.6-2.4l-5.6,32.8c9.6,4,27.2,8,45.6,8  c42.4,0,70.4-20,70.4-50.4c0-16.8-10.4-29.6-34.4-40c-14.4-7.2-23.2-11.2-23.2-18.4c0-6.4,7.2-12.8,23.2-12.8  c13.6,0,23.2,2.4,30.4,5.6l4,1.6L370.4,182L370.4,182z"></path><path style="fill:#3C58BF;" d="M439.2,180.4c-9.6,0-16.8,0.8-20.8,10.4l-60,133.6h43.2l8-24h51.2l4.8,24H504l-33.6-144H439.2z   M420.8,276.4c2.4-7.2,16-42.4,16-42.4s3.2-8.8,5.6-14.4l2.4,13.6c0,0,8,36,9.6,44h-33.6V276.4z"></path><path style="fill:#293688;" d="M448.8,180.4c-9.6,0-16.8,0.8-20.8,10.4l-69.6,133.6h43.2l8-24h51.2l4.8,24H504l-33.6-144H448.8z   M420.8,276.4c3.2-8,16-42.4,16-42.4s3.2-8.8,5.6-14.4l2.4,13.6c0,0,8,36,9.6,44h-33.6V276.4z"></path><path style="fill:#3C58BF;" d="M111.2,281.2l-4-20.8c-7.2-24-30.4-50.4-56-63.2l36,128h43.2l64.8-144H152L111.2,281.2z"></path><path style="fill:#293688;" d="M111.2,281.2l-4-20.8c-7.2-24-30.4-50.4-56-63.2l36,128h43.2l64.8-144H160L111.2,281.2z"></path><path style="fill:#FFBC00;" d="M0,180.4l7.2,1.6c51.2,12,86.4,42.4,100,78.4l-14.4-68c-2.4-9.6-9.6-12-18.4-12H0z"></path><path style="fill:#F7981D;" d="M0,180.4L0,180.4c51.2,12,93.6,43.2,107.2,79.2l-13.6-56.8c-2.4-9.6-10.4-15.2-19.2-15.2L0,180.4z"></path><path style="fill:#ED7C00;" d="M0,180.4L0,180.4c51.2,12,93.6,43.2,107.2,79.2l-9.6-31.2c-2.4-9.6-5.6-19.2-16.8-23.2L0,180.4z"></path><g><path style="fill:#051244;" d="M151.2,276.4L124,249.2l-12.8,30.4l-3.2-20c-7.2-24-30.4-50.4-56-63.2l36,128h43.2L151.2,276.4z"></path><polygon style="fill:#051244;" points="225.6,324.4 191.2,289.2 184.8,324.4  "></polygon><path style="fill:#051244;" d="M317.6,274.8L317.6,274.8c3.2,3.2,4.8,5.6,4,8.8c0,9.6-12.8,14.4-24,14.4c-16,0-24.8-2.4-38.4-8   l-5.6-2.4l-5.6,32.8c9.6,4,27.2,8,45.6,8c25.6,0,46.4-7.2,58.4-20L317.6,274.8z"></path><path style="fill:#051244;" d="M364,324.4h37.6l8-24h51.2l4.8,24H504L490.4,266l-48-46.4l2.4,12.8c0,0,8,36,9.6,44h-33.6   c3.2-8,16-42.4,16-42.4s3.2-8.8,5.6-14.4"></path>
</g></svg></span>
          </div>
        </div>
      </div>
    </section>
    
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa"><div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course</p>
    </div></footer> 
   
  </body>
</html>