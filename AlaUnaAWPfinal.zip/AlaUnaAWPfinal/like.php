<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wish</title>

    <link rel="stylesheet" href="like.css" media="screen" title="no title" charset="utf-8">
    <script src="https://code.jquery.com/jquery-2.2.4.js" charset="utf-8"></script>
    <meta name="robots" content="noindex,follow" />
    <link rel="stylesheet" href="nicepage.css" media="screen">
    <link rel="stylesheet" href="menu.css">
</head>

<body>
<?php
 require('loginAWP.php');
 ?>
    <div class="wrapper">
        <header class="page-header">
            <nav>
                <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png"
				width="120px" height="120px">
				</a>
                <ul>
                     <li class="dropdown" >
<a class="dropbtn"> New </a> 
<div class="dropdown-content">
    <a href="vintage-musical-instruments.php">vintage musical instruments</a>
    <a href="vintage-art-painting.php">vintage art painting</a>
    <a href="antiques.php">antiques</a>
    <a href="limited-musical-instruments.php">limited edition musical instruments</a>
    <a href="limited-art-painting.php">limited edition art painting</a>
    <a href="limited-pieces.php">limited edition pieces</a>

</div>
 </li>
                    <li>
                        <a href="Add-Pieces.php"> Add Piece  </a>
                    </li>
                    
                    <li>
                        <a href="about-us.php">About us  </a>
                    </li>
                </ul>
                <div class="cta-contact_2">
                    <button class="cta-contact">

                        <a href="like.php">
                            <img src="heart+like+love+valentine+icon-1320084901929215407_256.png"
                                width="20px" height="20px">
                        </a>
                    </button>

                    <button class="cta-contact">

                        <a href="cart.php">
                            <img src="cart.png" width="20px" height="20px">
                        </a>
                    </button>
                    <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
                    </button>
                    <?php
                    if($_SESSION['username']){
                    print"<a class='cta-contact' href='logout.php'> log out </a>";
                  }
                    ?>
                </div>
    </div>
    </nav>
    </header>
    </div>


    <div class="shopping-cart">
        <!-- Title -->
        <div class="title">
            Wish list
        </div>

        <!-- Product #1 -->
        <div class="item">
            <div class="image">
                <img src="sudhith-xavier-IUn1O500LMI-unsplash.jpg" width="100px" height="100px" alt="" />
            </div>

            <div class="description">
                <span>Phonograph</span>
                <span>since 1887</span>
                <span>Gold</span>
            </div>


            <div class="total-price">$549</div>
        </div>

        <!-- Product #2 -->
        <div class="item">

            <div class="image">
                <img src="seth-doyle-wYrByI2RKx8-unsplash.jpg" width="100px" height="100px" alt="" />
            </div>

            <div class="description">
                <span>Phonograph</span>
                <span>since 1890</span>
                <span>Green</span>
            </div>
            <div class="total-price">$870</div>
        </div>

    

        <!-- Product #3 -->
        <div class="item">

            <div class="image">
                <img src="sven-scheuermeier-XCBW03rNaNQ-unsplash.jpg" width="100px" height="100px" alt="" />
            </div>

            <div class="description">
                <span>Old Tv sinc </span>
                <span>1930</span>
                <span>Brown</span>
            </div>
            <div class="total-price">$349</div>
        </div>
    </div>
    </div>
       
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course</p>
      </div></footer>
</body>

</html>