<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="menu.css">
  <title>Profile</title>
  <link rel="stylesheet" href="profile.css">

  <style>
    footer {
      background-color: gray;
      padding-top: 50px;
      padding-bottom: 20px;
      font-size: x-large;
      text-align: center;
      padding-left: 200px;
      font-family: "Apple Color Emoji", "Segoe UI Emoji", "NotoColorEmoji", "Segoe UI Symbol", "Android Emoji", "EmojiSymbols";

    }

    header {
      font-family: "Apple Color Emoji", "Segoe UI Emoji", "NotoColorEmoji", "Segoe UI Symbol", "Android Emoji", "EmojiSymbols";
      ;
    }




    .u-body {

      background-image: url(the_foodies_place-removebg-preview.png);
      background-repeat: repeat;
      background-attachment: scroll;
      background-position: center;
      background-color: #e3ddcf;

    }
  </style>

</head>

<body class="u-body">
<?php
 require('loginAWP.php');
 ?>
  <!-- 
profile

https://codepen.io/juliepark/pen/pLMxoP

-->

  <div class="wrapper">
    <header class="page-header">
      <nav>
        <a href="Home.html" class="logo"><img src="the_foodies_place-removebg-preview.png" width="120px" height="120px">
        </a>
        <ul>
          <li class="dropdown">
            <a class="dropbtn"> New </a>
            <div class="dropdown-content">
              <a href="vintage-musical-instruments.html">vintage musical instruments</a>
              <a href="vintage-art-painting.html">vintage art painting</a>
              <a href="antiques.html">antiques</a>
              <a href="limited-musical-instruments.html">limited edition musical instruments</a>
              <a href="limited-art-painting.html">limited edition art painting</a>
              <a href="limited-pieces.html">limited edition pieces</a>

            </div>
          </li>
          <li>
            <a href="Add-Pieces.html"> Add Piece </a>
          </li>

          <li>
            <a href="about-us.html">About us </a>
          </li>
        </ul>
        <div class="cta-contact_2">
          <button class="cta-contact">

            <a href="like.html">
              <img src="heart+like+love+valentine+icon-1320084901929215407_256.png" width="20px" height="20px">
            </a>
          </button>

          <button class="cta-contact">

            <a href="cart.html">
              <img src="cart.png" width="20px" height="20px">
            </a>
          </button>
          <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }
          ?>
        </div>
  </div>
  </nav>
  </header>
  </div>


  </div>
  <div class="container">
    <div class="leftbox"></div>
    <div class="rightbox">
      <div class="profile">
          <h1>Personal Info</h1>
          <h2>Full Name</h2>
          <p>Julie Park </p>
          <h2>Birthday</h2>
          <p>July 21</p>
          <h2>Email</h2>
          <p>park@gmail.com </p>
          <h2>Password </h2>
          <p>••••••• </p>
          <h3><a href="Wallet.html">Wallet</a></h3>
          <h3><a href="Auctions.html"> Auctions</a></h3>
          <h3><a href="invoice.html"> Invoices</a></h3>
          <h3><a href="Ownership.html">Ownership Documents</a></h3>
          <h3><a href="delete.php">Delete Account </a></h3>
          <h3><a href="update.php">update password </a></h3>
          
        </form>

      </div>
    </div>
  </div>

  <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa">
    <div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with
        love by Umm Al-Qura University CS students in Internet applications course</p>
    </div>
  </footer>

</body>

</html>