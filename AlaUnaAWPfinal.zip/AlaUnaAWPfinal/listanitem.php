<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Lab6</title>

</head>
<body>

        
<?php 

ini_set ('display_errors', 1);
error_reporting (E_ALL & ~E_NOTICE);

// Handle form.

$filename = "UserUploads/";

if (!(file_exists($filename))) {
mkdir ("UserUploads/"); 
}
else{
// Count total files
//$countfiles = count($_FILES['file']['name']);

// Looping all files
for($i=0;$i<$countfiles;$i++){
$filename=$_FILES['file']['name'][$i];

move_uploaded_file($_FILES['file']['tmp_name'][$i],'UserUploads/'.$_FILES['file']['name'][$i]);


echo "<br>the file name :<br> $filename <br>And size
:".$_FILES['file']['size'][$i]."<br> And Type:
".$_FILES['file']['type'][$i];
}
}


?>

<?php 
if ( !empty ($_POST['select']) ) {	// Check for the required value.
	
  if ($selectfile = fopen ('..\PieceFile.txt', 'a+')) { // Try to open the file.
    

      $data = $_POST['select'];
      $decriptionPiece = $_POST['message'];
      foreach($data as $f){
        fwrite ($selectfile, "$f\n"); // Write the data. Use \r\n on Windows.
        
      
    }
  fwrite ($selectfile, "$decriptionPiece\n"); // Write the data. Use \r\n on Windows.
  fclose ($selectfile); // Close the file.
    
    // Print a message.
    print "<p>Your department has been stored.</p>";
  
  } else { // Could not open the file.
    print "<p>Your department could not be stored due to a system error.</p>";
  }
  
      // Read the file's contents into an array.
$dataselect = file ('..\PieceFile.txt');

foreach($dataselect as $f){
print '<p>' . trim ($f) . '</p>'; //This function returns a string with whitespace stripped from the beginning and end of string, remove no need charcters.

}


} else {
  print "<p>Please select your Department</p>"; // Failed to enter a fruit.

}

?> 

</body>
</html>
