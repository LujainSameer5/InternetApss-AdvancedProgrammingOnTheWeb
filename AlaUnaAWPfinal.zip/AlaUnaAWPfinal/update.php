<!DOCTYPE html>
<html style="font-size: 16px;">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>update password</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
    <link rel="stylesheet" href="about-us.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i">
    <link rel="stylesheet" href="menu.css">
    <style> 

    footer{
        margin-top: 200px;
    }
    h2{
        text-align: center;
    }
    input {
  padding: 1.3em 3em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 500;
  color: #000;
  background-color: #fff;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;}

button:hover {
  background-color: #23c483;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
  transform: translateY(-7px);
}

button:active {
  transform: translateY(-1px);
}
    body{
        background-color: burlywood;
    }

</style>


    <script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "Organization",
            "name": "ALA UNA",
            "logo": "images/alauna.png"
        }
    </script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="about us">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">
</head>

<body class="u-body" >
<?php
 require('loginAWP.php');
 ?>

    <div class="wrapper">
        <header class="page-header">
            <nav>
                <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png" width="120px" height="120px">
                </a>
                <ul>
                    <li class="dropdown">
                        <a class="dropbtn"> New </a>
                        <div class="dropdown-content">
                        <a href="vintage-musical-instruments.php">vintage musical instruments</a>
  <a href="vintage-art-painting.php">vintage art painting</a>
  <a href="antiques.php">antiques</a>
  <a href="limited-musical-instruments.php">limited edition musical instruments</a>
  <a href="limited-art-painting.php">limited edition art painting</a>
  <a href="limited-pieces.php">limited edition pieces</a>

                        </div>
                    </li>
                    <li>
                        <a href="Add-Pieces.php"> Add Piece </a>
                    </li>

                    <li>
                        <a href="about-us.php">About us </a>
                    </li>
                </ul>
                <div class="cta-contact_2">
                    <button class="cta-contact">

                        <a href="like.php">
                            <img src="heart+like+love+valentine+icon-1320084901929215407_256.png" width="20px" height="20px">
                        </a>
                    </button>

                    <button class="cta-contact">

                        <a href="cart.php">
                            <img src="cart.png" width="20px" height="20px">
                        </a>
                    </button>
                    <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }
          ?>
                </div>
    </div>
    </nav>
    </header>
    </div>


    <?php // Script 12.8 - edit_entry.php 
    // This script edits a blog entry using an UPDATE query.
    // Address error handling.
    ini_set('display_errors', 1);
    error_reporting(E_ALL & ~E_NOTICE);
    // Connect and select.
    if ($dbc = @mysqli_connect('localhost', 'root', '135791')) {
        if (!@mysqli_select_db($dbc, 'ala_una')) {
            die('<p>Could not select the database because: <b>' . mysqli_error($dbc) . '</b></p>');
        }
    } else {
        die('<p>Could not connect to MySQL because: <b>' . mysqli_error($dbc) . '</b></p>');
    }
    if (isset($_POST['submit'])) { // Handle the form.		
        // Define the query.	
        $query = "UPDATE user SET PASSWORD_='{$_POST['pw']}' WHERE USER_ID_={$_POST['id']}";
        $r = mysqli_query($dbc, $query); // Execute the query.		
        // Report on the result.	
        if (mysqli_affected_rows($dbc) == 1) {
            print '<p>The PASSWORD has been updated.</p>';
        } else {
            print "<p>Could not update the entry because: <b>" . mysqli_error($dbc) . "</b>. The query was $query.</p>";
        }
    } // End of main IF.
    mysqli_close($dbc); // Close the database connection.
    ?>
<div class="u-form u-form-1"class="u-clearfix u-form-spacing-10 u-form-vertical u-inner-form" source="custom" name="form" style="padding: 10px;">
<h2 > Update Password</h2>
<div class="u-form-group u-form-name">
        <form method="POST" action="update.php" >
            
                <input type="text" name="id" placeholder="Enter your id" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white" required=""> <br>

                <input type="text" name="name" placeholder="Enter your name" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white" required=""> <br>
                <input type="password" name="pw" placeholder="Enter your password" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white" required=""><br>
                <input type="submit" name="submit" value="update " class=" u-button-style">

        </form>
    </div>
    </div>
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa" >
        <div class="u-clearfix u-sheet u-sheet-1">
            <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with
                love by Umm Al-Qura University CS students in Internet applications course</p>
        </div>
    </footer>
</body>




</html>