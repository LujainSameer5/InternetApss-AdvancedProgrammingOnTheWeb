<!DOCTYPE html>
<html style="font-size: 16px;">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="keywords"
    content="Motivating Ways to Improve Your Skills, Leadership ​tips to improve your skills, The Innovative Technology Leader, Make learning easy, Simplicity Is Key, Online Classes, Managing Teams for Innovation and Success, Boost Your Leadership Skills, Executive Program in Strategy and Organization">
  <meta name="description" content="">
  <meta name="page_type" content="np-template-header-footer-from-plugin">
  <title>Home</title>
  <link rel="stylesheet" href="nicepage.css" media="screen">
  <link rel="stylesheet" href="Home.css" media="screen">
  <link rel="stylesheet" href="menu.css">
  <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
  <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
  <script type="text/javascript" src="vintage-art-painting.js"> </script>
  <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
  <link rel="stylesheet" href="menu.css">
  <link id="u-theme-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
  <link id="u-page-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i">

  <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
  <meta name="theme-color" content="#478ac9">
  <meta property="og:title" content="Home">
  <meta property="og:type" content="website">


</head>

<body >
<?php
 require('loginAWP.php');
 ?>
  <div class="wrapper">
    <header class="page-header">
      <nav>
        <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png" width="120px" height="120px">
        </a>
        <ul>
          <li class="dropdown">
            <a class="dropbtn"> New </a>
            <div class="dropdown-content">
              <a href="vintage-musical-instruments.php">vintage musical instruments</a>
              <a href="vintage-art-painting.php">vintage art painting</a>
              <a href="antiques.php">antiques</a>
              <a href="limited-musical-instruments.php">limited edition musical instruments</a>
              <a href="limited-art-painting.php">limited edition art painting</a>
              <a href="limited-pieces.php">limited edition pieces</a>

            </div>
          </li>
          <li>
            <a href="Add-Pieces.php"> Add Piece </a>
          </li>

          <li>
            <a href="about-us.php">About us </a>
          </li>
        </ul>
        <div class="cta-contact_2">
          <button class="cta-contact">

            <a href="like.php">
              <img src="heart+like+love+valentine+icon-1320084901929215407_256.png" width="20px" height="20px">
            </a>
          </button>

          <button class="cta-contact">

            <a href="cart.php">
              <img src="cart.png" width="20px" height="20px">
            </a>
          </button>
          <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }

          ?>
        </div>
  </div>
  </nav>
  </header>
  </div>


  <body class="u-body">
    <header class="u-align-center-sm u-align-center-xs u-clearfix u-header u-header" id="sec-f4a0">
      <div class="u-align-left u-clearfix u-sheet u-sheet-1"></div>
    </header>
    <section class="u-clearfix u-custom-color-3 u-section-1" id="sec-2693">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-custom-color-1 u-shape u-shape-rectangle u-shape-1"></div>
        <div class="u-custom-color-4 u-expanded-width-xs u-shape u-shape-rectangle u-shape-2"></div>
        <img class="u-image u-image-1" src="photo-1616315168316-61d6e5f16ead.jfif" data-image-width="928"
          data-image-height="1160">
        <div class="u-align-left u-container-style u-custom-color-1 u-group u-group-1">
          <div class="u-container-layout u-container-layout-1">
            <p class="u-align-center u-large-text u-text u-text-variant u-text-1">
              <span style="font-size: 2.25rem; font-weight: 700;" class="u-text-custom-color-4">Our mission:<br>
                <span style="font-weight: 400;">&nbsp;We aspire to spread knowledge about the importance of rare
                  pieces</span>
              </span>
            </p>
          </div>
        </div>
        <h1 class="u-align-center u-custom-font u-font-merriweather u-text u-text-custom-color-1 u-text-2">ALA UNA
          AUCTION
        </h1>
      </div>
    </section>
    <section class="u-clearfix u-custom-color-4 u-section-2" id="sec-e668">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-align-left u-container-style u-image u-layout-cell u-left-cell u-size-30 u-image-1"
                data-image-width="400" data-image-height="374">
                <div class="u-container-layout u-container-layout-1"></div>
              </div>
              <div
                class="u-align-left u-container-style u-custom-color-1 u-layout-cell u-right-cell u-size-30 u-layout-cell-2">
                <div class="u-container-layout u-container-layout-2">
                  <h1 class="u-custom-font u-font-merriweather u-text u-text-1">
                    <span class="u-text-custom-color-4">Elephant</span>
                    <span class="u-text-custom-color-4">Pair Rare Chinese Antique&nbsp;</span>
                  </h1>
                  <p class="u-text u-text-2">
                    <span class="u-text-custom-color-4"></span>
                    <span style="font-size: 1.5rem;" class="u-text-custom-color-4">Announcement of an auction on a rare
                      masterpiece....., the auction will be held on Sunday, June 26,per hour 4 pm and the auction period
                      will be half an hour only. For those who wish to participate&nbsp; </span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <strong>
      <div id="countdown6"></div>
    </strong>
    <section class="u-clearfix u-custom-color-3 u-section-3" id="carousel_df22">
      <div class="u-clearfix u-sheet u-valign-middle-sm u-valign-middle-xs u-sheet-1">
        <div class="u-custom-color-2 u-shape u-shape-rectangle u-shape-1"></div>
        <img class="u-image u-image-1" src="H19947-L272612280.jpg" data-image-width="714" data-image-height="914">
        <div id="carousel-5989" data-interval="5000" data-u-ride="carousel" class="u-carousel u-slider u-slider-1">
          <ol class="u-absolute-hcenter u-carousel-indicators u-hidden-sm u-hidden-xs u-carousel-indicators-1">
            <li data-u-target="#carousel-5989" class="u-active u-grey-30 u-shape-circle" data-u-slide-to="0"
              style="width: 10px; height: 10px;"></li>
            <li data-u-target="#carousel-5989" class="u-grey-30 u-shape-circle" data-u-slide-to="1"
              style="width: 10px; height: 10px;"></li>
          </ol>
          <div class="u-carousel-inner" role="listbox">
            <div
              class="u-active u-align-left u-carousel-item u-container-style u-custom-color-4 u-slide u-carousel-item-1">
              <div class="u-container-layout u-valign-top-md u-valign-top-sm u-valign-top-xs u-container-layout-1">
                <h2 class="u-custom-font u-font-merriweather u-text u-text-custom-color-1 u-text-1">Pastel Gathering
                </h2>
                <p class="u-large-text u-text u-text-variant u-text-2">
                  <span style="font-size: 1.5rem;">Announcement of an auction on a painting....., the auction will be
                    held
                    on Saturday, June 27,per hou​r 2 pm and the auction period will be half an hour only. For those who
                    wish to participate&nbsp;</span>
                  <br>
                  <br>
                  <br>
                </p>
              </div>
            </div>
            <div
              class="u-align-left u-carousel-item u-container-style u-custom-color-4 u-expanded-width-lg u-expanded-width-xl u-slide u-carousel-item-2">
              <div
                class="u-container-layout u-valign-middle-lg u-valign-middle-xl u-valign-top-md u-valign-top-sm u-valign-top-xs u-container-layout-2">
                <p class="u-large-text u-text u-text-variant u-text-3">"<span style="font-size: 1.5rem;">Pastel
                    Gathering"
                    is a limited edition serigraph on paper by Isaac Maimon, numbe​red and hand signed by the artist.
                    Includes Letter of Authenticity. Measures approx. 19" x 24" (border), 16.5" x 21.5".</span>
                </p>
              </div>
            </div>
          </div>
          <strong>
            <div id="countdown15"></div>
          </strong>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-prev u-icon-rectangle u-spacing-11 u-text-hover-grey-70 u-white u-carousel-control-1"
            href="#carousel-5989" role="button" data-u-slide="prev">
            <span aria-hidden="true">
              <svg viewBox="0 0 477.175 477.175">
                <path d="M145.188,238.575l215.5-215.5c5.3-5.3,5.3-13.8,0-19.1s-13.8-5.3-19.1,0l-225.1,225.1c-5.3,5.3-5.3,13.8,0,19.1l225.1,225
		c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4c5.3-5.3,5.3-13.8,0-19.1L145.188,238.575z"></path>
              </svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 477.175 477.175">
                <path d="M145.188,238.575l215.5-215.5c5.3-5.3,5.3-13.8,0-19.1s-13.8-5.3-19.1,0l-225.1,225.1c-5.3,5.3-5.3,13.8,0,19.1l225.1,225
		c2.6,2.6,6.1,4,9.5,4s6.9-1.3,9.5-4c5.3-5.3,5.3-13.8,0-19.1L145.188,238.575z"></path>
              </svg>
            </span>
          </a>
          <a class="u-absolute-vcenter u-carousel-control u-carousel-control-next u-icon-rectangle u-spacing-11 u-text-hover-grey-70 u-white u-carousel-control-2"
            href="#carousel-5989" role="button" data-u-slide="next">
            <span aria-hidden="true">
              <svg viewBox="0 0 477.175 477.175">
                <path
                  d="M360.731,229.075l-225.1-225.1c-5.3-5.3-13.8-5.3-19.1,0s-5.3,13.8,0,19.1l215.5,215.5l-215.5,215.5
		c-5.3,5.3-5.3,13.8,0,19.1c2.6,2.6,6.1,4,9.5,4c3.4,0,6.9-1.3,9.5-4l225.1-225.1C365.931,242.875,365.931,234.275,360.731,229.075z">
                </path>
              </svg>
            </span>
            <span class="sr-only">
              <svg viewBox="0 0 477.175 477.175">
                <path
                  d="M360.731,229.075l-225.1-225.1c-5.3-5.3-13.8-5.3-19.1,0s-5.3,13.8,0,19.1l215.5,215.5l-215.5,215.5
		c-5.3,5.3-5.3,13.8,0,19.1c2.6,2.6,6.1,4,9.5,4c3.4,0,6.9-1.3,9.5-4l225.1-225.1C365.931,242.875,365.931,234.275,360.731,229.075z">
                </path>
              </svg>
            </span>
          </a>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-custom-color-4 u-section-4" id="carousel_912c">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-custom-color-1 u-shape u-shape-rectangle u-shape-1"></div>
        <img class="u-image u-image-default u-image-1" data-image-width="400" data-image-height="300"
          src="images/s-l40018.jpg">
        <div class="u-align-left u-container-style u-custom-color-1 u-group u-group-1">
          <div class="u-container-layout u-container-layout-1">
            <h5 class="u-custom-font u-text u-text-custom-color-4 u-text-font u-text-1">Announcement of an auction on a
              rare masterpiece....., the auction will be held on Wednesday, June 29,per hour 3 pm and the auction period
              will be It's an hour long only. For those who wish to participate&nbsp;</h5>
          </div>
        </div>
        <h1 class="u-custom-font u-font-merriweather u-text u-text-custom-color-3 u-text-2">
          <span class="u-text-custom-color-1" style="font-weight: 700;">
            <span style="font-size: 2.25rem;">Antique Vintage Style Wrought Iron Trunk Chest Box Crab Lock Key
              Padlock</span>&nbsp;
          </span>
          <span style="font-size: 1.25rem;"></span>
        </h1>
        <strong>
          <div id="countdown7"></div>
        </strong>
      </div>
    </section>


    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with
          love by Umm Al-Qura University CS students in Internet applications course</p>
      </div>
    </footer>

  </body>

</html>