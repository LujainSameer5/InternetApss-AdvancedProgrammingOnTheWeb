<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>limited pieces</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="limited-pieces.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <script  type="text/javascript" src="vintage-art-painting.js"> </script> 
    <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link rel="stylesheet" href="menu.css">
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "ALA UNA",
		"logo": "images/alauna.png"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="limited pieces">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body">
    <?php
 require('loginAWP.php');
 ?>
    
   <div class="wrapper">
    <header class="page-header">
        <nav>
            <a href="Home.html" class="logo"><img src="the_foodies_place-removebg-preview.png"
    width="120px" height="120px">
    </a>
            <ul>
                 <li class="dropdown" >
<a class="dropbtn"> New </a> 
<div class="dropdown-content">
  <a href="vintage-musical-instruments.php">vintage musical instruments</a>
  <a href="vintage-art-painting.php">vintage art painting</a>
  <a href="antiques.php">antiques</a>
  <a href="limited-musical-instruments.php">limited edition musical instruments</a>
  <a href="limited-art-painting.php">limited edition art painting</a>
  <a href="limited-pieces.php">limited edition pieces</a>

</div>
</li>
                <li>
                    <a href="Add-Pieces.php"> Add Piece  </a>
                </li>
                
                <li>
                    <a href="about-us.php">About us  </a>
                </li>
            </ul>
            <div class="cta-contact_2">
                <button class="cta-contact">

                    <a href="like.php">
                        <img src="heart+like+love+valentine+icon-1320084901929215407_256.png"
                            width="20px" height="20px">
                    </a>
                </button>

                <button class="cta-contact">

                    <a href="cart.php">
                        <img src="cart.png" width="20px" height="20px">
                    </a>
                </button>
                <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
                </button>
                <?php
                if($_SESSION['username']){
                print"<a class='cta-contact' href='logout.php'> log out </a>";
              }
                ?>
            </div>
</div>
</nav>
</header>
</div>

    <section class="u-clearfix u-section-1" id="sec-a2a6">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-row">
              <div class="u-container-style u-layout-cell u-size-30 u-layout-cell-1">
                <div class="u-container-layout u-container-layout-1">
                  <div class="u-border-2 u-border-custom-color-3 u-shape u-shape-bottom u-shape-1"></div>
                  <img class="u-image u-image-round u-preserve-proportions u-radius-10 u-image-1" src="pair-of-19th-century-imari-napoleon-iii-oil-lanterns.jpg" alt="" data-image-width="800" data-image-height="800">
                  <div class="fr-view u-clearfix u-rich-text u-text u-text-1">
                    <h4>Pair of 19th Century Imari Napoleon III Oil Lanterns</h4>
                    <p>Pair 19th Century Imari Oil Lanterns were imported from Japan into Europe during the height of their popularity at the middle of the 19th century, and were essential to affluent homes prior to the widespread existence of electric lighting networks. &nbsp;This pair, hand-painted to perfection, have remained in exquisite condition, and will be instantaneous conversation starters to all who appreciate the finest hand-crafted heirlooms from this bygone era!<br style="color: rgb(0, 0, 0); font-family: &quot;Times New Roman&quot;; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Circa 1870s<br style="color: rgb(0, 0, 0); font-family: &quot;Times New Roman&quot;; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Sold as a pair, each measures 22H x 6 in Diamete&nbsp;
                    </p>
                    <h4 style="text-align: left;">age:151</h4>
                    <h4 style="text-align: left;">price: $1,400</h4>
                    <h4 style="text-align: left;">End Date: 2021/12/12</h4>
                    <div id="countdown21"></div>
                  </div>
                  <a href="none" class="u-active-none u-border-none u-btn u-button-style u-custom-color-3 u-hover-none u-text-custom-color-5 u-text-hover-palette-3-light-1 u-btn-1"><span class="u-icon u-text-palette-2-base"><svg class="u-svg-content" viewBox="0 0 511.334 511.334" style="width: 1em; height: 1em;"><path d="m506.887 114.74c-3.979-5.097-10.086-8.076-16.553-8.076h-399.808l-5.943-66.207c-.972-10.827-10.046-19.123-20.916-19.123h-42.667c-11.598 0-21 9.402-21 21s9.402 21 21 21h23.468l23.018 256.439c.005.302-.01.599.007.903.047.806.152 1.594.286 2.37l.842 9.376c.016.177.034.354.055.529 2.552 22.11 13.851 41.267 30.19 54.21-8.466 10.812-13.532 24.407-13.532 39.172 0 35.106 28.561 63.667 63.666 63.667 35.106 0 63.667-28.561 63.667-63.667 0-7.605-1.345-14.9-3.801-21.667h114.936c-2.457 6.767-3.801 14.062-3.801 21.667 0 35.106 28.561 63.667 63.667 63.667s63.667-28.561 63.667-63.667-28.561-63.667-63.667-63.667h-234.526c-15.952 0-29.853-9.624-35.853-23.646l335.608-19.724c9.162-.538 16.914-6.966 19.141-15.87l42.67-170.67c1.567-6.272.158-12.918-3.821-18.016z"></path></svg><img></span>&nbsp;Add to cart
                  </a>
                  <a href="none" class="u-border-2 u-border-custom-color-3 u-border-hover-palette-3-base u-btn u-btn-round u-button-style u-none u-radius-50 u-text-palette-2-base u-btn-2"><span class="u-icon u-icon-2"><svg class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" style="width: 1em; height: 1em;"><path d="M376,30c-27.783,0-53.255,8.804-75.707,26.168c-21.525,16.647-35.856,37.85-44.293,53.268 c-8.437-15.419-22.768-36.621-44.293-53.268C189.255,38.804,163.783,30,136,30C58.468,30,0,93.417,0,177.514 c0,90.854,72.943,153.015,183.369,247.118c18.752,15.981,40.007,34.095,62.099,53.414C248.38,480.596,252.12,482,256,482 s7.62-1.404,10.532-3.953c22.094-19.322,43.348-37.435,62.111-53.425C439.057,330.529,512,268.368,512,177.514 C512,93.417,453.532,30,376,30z"></path></svg><img></span> .
                  </a>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-size-30 u-layout-cell-2">
                <div class="u-container-layout u-container-layout-2">
                  <div class="u-border-2 u-border-custom-color-3 u-shape u-shape-bottom u-shape-2"></div>
                  <img class="u-image u-image-round u-preserve-proportions u-radius-10 u-image-2" src="pair-19th-century-hand-painted-porcelain-bronze-oil-lanterns.jpg" alt="" data-image-width="800" data-image-height="800">
                  <div class="fr-view u-clearfix u-rich-text u-text u-text-2">
                    <h4>Pair 19th Century Hand-Painted Porcelain &amp; Bronze Oil Lanterns</h4>
                    <p style="text-align: left;">Pair 19th Century Hand-Painted Porcelain &amp; Bronze Oil Lanterns are exquisite works of art executed in amazing detail and vibrant color by hand, then glazed to preserve the beauty for centuries! &nbsp;Mounted on bronze bases and fitted with bronze caps and mantels, each has a hurricane glass that would keep the flame protected from errant wind and provide consistent and romantic lighting for the room. &nbsp;Amazingly well preserved!<br style="color: rgb(0, 0, 0); font-family: &quot;Times New Roman&quot;; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Circa 1870s<br style="color: rgb(0, 0, 0); font-family: &quot;Times New Roman&quot;; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial;">Each measures 28.5H x 5 in diameter including hurricane glass tops <span style="line-height: 2.0;">&nbsp;</span>
                    </p>
                    <h4 style="text-align: left;">age: 151</h4>
                    <h4 style="text-align: left;">price: $2,750</h4>
                    <h4 style="text-align: left;">End Date: 2021/12/25</h4>
                    <div id="countdown22"></div>
                  </div>
                  <a href="none" class="u-active-none u-border-none u-btn u-button-style u-custom-color-3 u-hover-none u-text-custom-color-5 u-text-hover-palette-3-light-1 u-btn-3"><span class="u-icon u-text-palette-2-base"><svg class="u-svg-content" viewBox="0 0 511.334 511.334" style="width: 1em; height: 1em;"><path d="m506.887 114.74c-3.979-5.097-10.086-8.076-16.553-8.076h-399.808l-5.943-66.207c-.972-10.827-10.046-19.123-20.916-19.123h-42.667c-11.598 0-21 9.402-21 21s9.402 21 21 21h23.468l23.018 256.439c.005.302-.01.599.007.903.047.806.152 1.594.286 2.37l.842 9.376c.016.177.034.354.055.529 2.552 22.11 13.851 41.267 30.19 54.21-8.466 10.812-13.532 24.407-13.532 39.172 0 35.106 28.561 63.667 63.666 63.667 35.106 0 63.667-28.561 63.667-63.667 0-7.605-1.345-14.9-3.801-21.667h114.936c-2.457 6.767-3.801 14.062-3.801 21.667 0 35.106 28.561 63.667 63.667 63.667s63.667-28.561 63.667-63.667-28.561-63.667-63.667-63.667h-234.526c-15.952 0-29.853-9.624-35.853-23.646l335.608-19.724c9.162-.538 16.914-6.966 19.141-15.87l42.67-170.67c1.567-6.272.158-12.918-3.821-18.016z"></path></svg><img></span>&nbsp;Add to cart
                  </a>
                  <a href="none" class="u-border-2 u-border-custom-color-3 u-border-hover-palette-3-base u-btn u-btn-round u-button-style u-none u-radius-50 u-text-palette-2-base u-btn-4"><span class="u-icon u-icon-4"><svg class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" style="width: 1em; height: 1em;"><path d="M376,30c-27.783,0-53.255,8.804-75.707,26.168c-21.525,16.647-35.856,37.85-44.293,53.268 c-8.437-15.419-22.768-36.621-44.293-53.268C189.255,38.804,163.783,30,136,30C58.468,30,0,93.417,0,177.514 c0,90.854,72.943,153.015,183.369,247.118c18.752,15.981,40.007,34.095,62.099,53.414C248.38,480.596,252.12,482,256,482 s7.62-1.404,10.532-3.953c22.094-19.322,43.348-37.435,62.111-53.425C439.057,330.529,512,268.368,512,177.514 C512,93.417,453.532,30,376,30z"></path></svg><img></span> .
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-align-left u-clearfix u-section-2" id="sec-4ee5">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-row">
              <div class="u-container-style u-layout-cell u-size-30 u-layout-cell-1">
                <div class="u-container-layout u-container-layout-1">
                  <div class="u-border-2 u-border-custom-color-3 u-shape u-shape-bottom u-shape-1"></div>
                  <img class="u-image u-image-round u-preserve-proportions u-radius-10 u-image-1" src="pair-19th-century-giltwood-candlestick-table-lamps.jpg" alt="" data-image-width="800" data-image-height="800">
                  <div class="fr-view u-clearfix u-rich-text u-text u-text-1">
                    <h4>Pair 19th Century Giltwood Candlestick Table Lamp</h4>
                    <p>Pair 19th Century Giltwood Candlestick Table Lamps are a handsome example of fine woodworking, and feature the original gilded finish. &nbsp;Price includes electrification and shades as shown.</p>
                    <p>Circa 1880s</p>
                    <p>Each measures 38H x 8 in diameter (before harp &amp; shade)</p>
                    <h4 style="text-align: left;">age: 141</h4>
                    <h4 style="text-align: left;">price: $1,850</h4>
                    <h4 style="text-align: left;">End Date: 2022/1/15</h4>
                    <div id="countdown23"></div>
                  </div>
                  <a href="none" class="u-active-none u-border-none u-btn u-button-style u-custom-color-3 u-hover-none u-text-custom-color-5 u-text-hover-palette-3-light-1 u-btn-1"><span class="u-icon u-text-palette-2-base"><svg class="u-svg-content" viewBox="0 0 511.334 511.334" style="width: 1em; height: 1em;"><path d="m506.887 114.74c-3.979-5.097-10.086-8.076-16.553-8.076h-399.808l-5.943-66.207c-.972-10.827-10.046-19.123-20.916-19.123h-42.667c-11.598 0-21 9.402-21 21s9.402 21 21 21h23.468l23.018 256.439c.005.302-.01.599.007.903.047.806.152 1.594.286 2.37l.842 9.376c.016.177.034.354.055.529 2.552 22.11 13.851 41.267 30.19 54.21-8.466 10.812-13.532 24.407-13.532 39.172 0 35.106 28.561 63.667 63.666 63.667 35.106 0 63.667-28.561 63.667-63.667 0-7.605-1.345-14.9-3.801-21.667h114.936c-2.457 6.767-3.801 14.062-3.801 21.667 0 35.106 28.561 63.667 63.667 63.667s63.667-28.561 63.667-63.667-28.561-63.667-63.667-63.667h-234.526c-15.952 0-29.853-9.624-35.853-23.646l335.608-19.724c9.162-.538 16.914-6.966 19.141-15.87l42.67-170.67c1.567-6.272.158-12.918-3.821-18.016z"></path></svg><img></span>&nbsp;Add to cart
                  </a>
                  <a href="none" class="u-border-2 u-border-custom-color-3 u-border-hover-palette-3-base u-btn u-btn-round u-button-style u-none u-radius-50 u-text-palette-2-base u-btn-2"><span class="u-icon u-icon-2"><svg class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" style="width: 1em; height: 1em;"><path d="M376,30c-27.783,0-53.255,8.804-75.707,26.168c-21.525,16.647-35.856,37.85-44.293,53.268 c-8.437-15.419-22.768-36.621-44.293-53.268C189.255,38.804,163.783,30,136,30C58.468,30,0,93.417,0,177.514 c0,90.854,72.943,153.015,183.369,247.118c18.752,15.981,40.007,34.095,62.099,53.414C248.38,480.596,252.12,482,256,482 s7.62-1.404,10.532-3.953c22.094-19.322,43.348-37.435,62.111-53.425C439.057,330.529,512,268.368,512,177.514 C512,93.417,453.532,30,376,30z"></path></svg><img></span> .
                  </a>
                </div>
              </div>
              <div class="u-container-style u-layout-cell u-size-30 u-layout-cell-2">
                <div class="u-container-layout u-container-layout-2">
                  <div class="u-border-2 u-border-custom-color-3 u-shape u-shape-bottom u-shape-2"></div>
                  <img class="u-image u-image-round u-preserve-proportions u-radius-10 u-image-2" src="19th-century-milk-glass-oil-lantern-newly-electrified.jpg" alt="" data-image-width="800" data-image-height="800">
                  <div class="fr-view u-clearfix u-rich-text u-text u-text-2">
                    <h4>19th Century Milk Glass Oil Lantern (newly electrified)</h4>
                    <p>19th Century Milk Glass Oil Lantern originally held a small reservoir and hurricane glass, but will be cleverly converted to an electric table lamp for years of enjoyment in style!</p>
                    <p>Circa 1890s</p>
                    <p>Measures 24H x 6 in diameter (shade not included</p>
                    <h4 style="text-align: left;">age: 131</h4>
                    <h4 style="text-align: left;">price: $600</h4>
                    <h4 style="text-align: left;">End Date: 2022/1/9</h4>
                    <div id="countdown24"></div>
                  </div>
                  <a href="none" class="u-active-none u-border-none u-btn u-button-style u-custom-color-3 u-hover-none u-text-custom-color-5 u-text-hover-palette-3-light-1 u-btn-3"><span class="u-icon u-text-palette-2-base"><svg class="u-svg-content" viewBox="0 0 511.334 511.334" style="width: 1em; height: 1em;"><path d="m506.887 114.74c-3.979-5.097-10.086-8.076-16.553-8.076h-399.808l-5.943-66.207c-.972-10.827-10.046-19.123-20.916-19.123h-42.667c-11.598 0-21 9.402-21 21s9.402 21 21 21h23.468l23.018 256.439c.005.302-.01.599.007.903.047.806.152 1.594.286 2.37l.842 9.376c.016.177.034.354.055.529 2.552 22.11 13.851 41.267 30.19 54.21-8.466 10.812-13.532 24.407-13.532 39.172 0 35.106 28.561 63.667 63.666 63.667 35.106 0 63.667-28.561 63.667-63.667 0-7.605-1.345-14.9-3.801-21.667h114.936c-2.457 6.767-3.801 14.062-3.801 21.667 0 35.106 28.561 63.667 63.667 63.667s63.667-28.561 63.667-63.667-28.561-63.667-63.667-63.667h-234.526c-15.952 0-29.853-9.624-35.853-23.646l335.608-19.724c9.162-.538 16.914-6.966 19.141-15.87l42.67-170.67c1.567-6.272.158-12.918-3.821-18.016z"></path></svg><img></span>&nbsp;Add to cart
                  </a>
                  <a href="none" class="u-border-2 u-border-custom-color-3 u-border-hover-palette-3-base u-btn u-btn-round u-button-style u-none u-radius-50 u-text-palette-2-base u-btn-4"><span class="u-icon u-icon-4"><svg class="u-svg-content" viewBox="0 0 512 512" x="0px" y="0px" style="width: 1em; height: 1em;"><path d="M376,30c-27.783,0-53.255,8.804-75.707,26.168c-21.525,16.647-35.856,37.85-44.293,53.268 c-8.437-15.419-22.768-36.621-44.293-53.268C189.255,38.804,163.783,30,136,30C58.468,30,0,93.417,0,177.514 c0,90.854,72.943,153.015,183.369,247.118c18.752,15.981,40.007,34.095,62.099,53.414C248.38,480.596,252.12,482,256,482 s7.62-1.404,10.532-3.953c22.094-19.322,43.348-37.435,62.111-53.425C439.057,330.529,512,268.368,512,177.514 C512,93.417,453.532,30,376,30z"></path></svg><img></span> .
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa"><div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course</p>
    </div></footer> 
  </body>
</html>