<!DOCTYPE html>
<html style="font-size: 16px;">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="page_type" content="np-template-header-footer-from-plugin">
  <title>Add Pieces</title>
  <link rel="stylesheet" href="nicepage.css" media="screen">
  <link rel="stylesheet" href="Add-Pieces.css" media="screen">
  <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
  <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
  <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
  <link id="u-theme-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
  <link id="u-page-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i">
  <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "ALA UNA",
		"logo": "images/alauna.png"
}</script>
  <meta name="theme-color" content="#478ac9">
  <meta property="og:title" content="Add Pieces">
  <meta property="og:description" content="">
  <meta property="og:type" content="website">
  <link rel="stylesheet" href="menu.css">


 

</head>

<body class="u-body">
<?php
 require('loginAWP.php');
 ?>
  <div class="wrapper">
    <header class="page-header">
      <nav>
        <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png" width="120px" height="120px">
        </a>
        <ul>
          <li class="dropdown">
            <a class="dropbtn"> New </a>
            <div class="dropdown-content">
              <a href="vintage-musical-instruments.php">vintage musical instruments</a>
              <a href="vintage-art-painting.php">vintage art painting</a>
              <a href="antiques.php">antiques</a>
              <a href="limited-musical-instruments.php">limited edition musical instruments</a>
              <a href="limited-art-painting.php">limited edition art painting</a>
              <a href="limited-pieces.php">limited edition pieces</a>

            </div>
          </li>
          <li>
            <a href="Add-Pieces.php"> Add Piece </a>
          </li>

          <li>
            <a href="about-us.php">About us </a>
          </li>
        </ul>
        <div class="cta-contact_2">
          <button class="cta-contact">

            <a href="like.php">
              <img src="heart+like+love+valentine+icon-1320084901929215407_256.png" width="20px" height="20px">
            </a>
          </button>

          <button class="cta-contact">

            <a href="cart.php">
              <img src="cart.png" width="20px" height="20px">
            </a>
          </button>
          <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }
          ?>
        </div>
  </div>
  </nav>
  </header>
  </div>
  <section class="u-clearfix u-image u-section-1" id="sec-9a63" data-image-width="1400" data-image-height="980">
    <div class="u-clearfix u-sheet u-sheet-1">
      <div class="u-border-3 u-border-grey-40 u-container-style u-group u-white u-group-1">
        <div class="u-container-layout u-container-layout-1">
          <h2 class="u-align-center u-custom-font u-font-merriweather u-text u-text-custom-color-6 u-text-1">Add Your
            Own Pieces</h2>
          <p class="u-align-left u-large-text u-text u-text-variant u-text-2">
            <span style="font-size: 1.5rem;">Now you can sell all of your vintage Items in any upcoming Auction</span>
          </p>
          <a href="list-an-item.html" data-page-id="878307141"
            class="u-border-none u-btn u-btn-round u-button-style u-hover-palette-2-dark-1 u-palette-2-dark-2 u-radius-50 u-btn-1">List
            an item</a>
        </div>
      </div>
    </div>
  </section>


  <footer class="u-clearfix u-custom-color-3 u-footer" id="sec-44a5" style="background-color: grey;">
    <div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-align-center u-text u-text-1">© 2021 <span style="font-size: 1.125rem;"></span>© Copyright 2021. All
        rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course
      </p>
    </div>
  </footer>
</body>

</html>