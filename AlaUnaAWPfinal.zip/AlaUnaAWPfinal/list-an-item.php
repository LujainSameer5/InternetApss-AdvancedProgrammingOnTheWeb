<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>list an item</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="list-an-item.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i">
    <link rel="stylesheet" href="menu.css">
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "ALA UNA",
		"logo": "images/alauna.png"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="list an item">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">


    <style> 
    
    form{

      text-align: center;
    }

    .u-body{

      background-image: url(the_foodies_place-removebg-preview.png);
      background-repeat:repeat;
      background-attachment: scroll;
      background-position: center;
      background-color: #e3ddcf;

    }

    </style>

  </head>
  <body class="u-body">
    <?php
    require('loginAWP.php');
    ?>
    <div class="wrapper">
      <header class="page-header">
          <nav>
              <a href="Home.html" class="logo"><img src="the_foodies_place-removebg-preview.png"
      width="120px" height="120px">
      </a>
              <ul>
                   <li class="dropdown" >
<a class="dropbtn"> New </a> 
<div class="dropdown-content">
  <a href="vintage-musical-instruments.php">vintage musical instruments</a>
  <a href="vintage-art-painting.php">vintage art painting</a>
  <a href="antiques.php">antiques</a>
  <a href="limited-musical-instruments.php">limited edition musical instruments</a>
  <a href="limited-art-painting.php">limited edition art painting</a>
  <a href="limited-pieces.php">limited edition pieces</a>

</div>
</li>
                  <li>
                      <a href="Add-Pieces.php"> Add Piece  </a>
                  </li>
                  
                  <li>
                      <a href="about-us.php">About us  </a>
                  </li>
              </ul>
              <div class="cta-contact_2">
                  <button class="cta-contact">

                      <a href="like.php">
                          <img src="heart+like+love+valentine+icon-1320084901929215407_256.png"
                              width="20px" height="20px">
                      </a>
                  </button>

                  <button class="cta-contact">

                      <a href="cart.php">
                          <img src="cart.png" width="20px" height="20px">
                      </a>
                  </button>
                  <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
                  </button>
                  <?php
                  if($_SESSION['username']){
                  print"<a class='cta-contact' href='logout.php'> log out </a>";
                }
                  ?>
              </div>
  </div>
  </nav>
  </header>
  </div>
    <section class="u-clearfix u-custom-color-7 u-section-1" id="sec-4f84">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-border-3 u-border-custom-color-6 u-container-style u-group u-white u-group-1">
          <div class="u-container-layout u-container-layout-1">
            <h1 class="u-align-center u-custom-font u-font-merriweather u-text u-text-1">
              <span style="font-size: 1.5rem; font-weight: 400;">Fill The Form</span>&nbsp;<span style="font-size: 1.875rem;"></span>
            </h1>
          </div>
        </div>
        <div class="u-form u-form-1">
          <form action="listanitem.php" method="POST"  name="form" style="padding: 10px;" enctype="multipart/form-data">
            <div>

              <div>
                 <select name="select[]" multiple>
                  <option value="Vintage musical instrument">Vintage musical instrument</option>
                  <option value="Vintage art painting">Vintage art painting</option>
                  <option value="Antiques">Antiques</option>
                  <option value="Limited pieces">Limited pieces</option>
                  <option value="Limited edition musical instrument">Limited edition musical instrument</option>
                  <option value="Limited edition painting">Limited edition painting</option>
                </select>
      
              </div>
            </div>
            <div class="u-form-group u-form-message">
                 <label for="message-9c3c" class="u-form-control-hidden u-label"></label>
              <textarea placeholder="Enter item description and price " rows="4" cols="50" id="message" name="message" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-white" required=""></textarea>
              <label for="message-9c3c" class="u-form-control-hidden u-label"></label> 
              <input type="file" name="file[]" id="file" multiple>
            </div>
            <div class="u-align-left u-form-group u-form-submit">
              <input type="submit" name="submit"  value='Upload' class="u-btn u-btn-submit u-button-style">
              </div> 
            <div class="u-form-send-message u-form-send-success"> Thank you! Your message has been sent. </div>
            <div class="u-form-send-error u-form-send-message"> Unable to send your message. Please fix errors then try again. </div>
          </form>
        </div>
      </div>
    </section>
    
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa"><div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course</p>
    </div></footer> 
  </body>
</html>
