<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Wallet</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="Wallet.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.29.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link rel="stylesheet" href="menu.css">
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Site1",
		"logo": "images/a.jpg"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="Wallet">
    <meta property="og:description" content="">
    <meta property="og:type" content="website">

  

  </head>
  <body class="u-body">
  <?php
 require('loginAWP.php');
 ?>
    <div class="wrapper">
      <header class="page-header">
          <nav>
              <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png"
      width="120px" height="120px">
      </a>
              <ul>
                   <li class="dropdown" >
<a class="dropbtn"> New </a> 
<div class="dropdown-content">
<a href="vintage-musical-instruments.php">vintage musical instruments</a>
              <a href="vintage-art-painting.php">vintage art painting</a>
              <a href="antiques.php">antiques</a>
              <a href="limited-musical-instruments.php">limited edition musical instruments</a>
              <a href="limited-art-painting.php">limited edition art painting</a>
              <a href="limited-pieces.php">limited edition pieces</a>

</div>
</li>
                  <li>
                      <a href="Add-Pieces.php"> Add Piece  </a>
                  </li>
                  
                  <li>
                      <a href="about-us.php">About us  </a>
                  </li>
              </ul>
              <div class="cta-contact_2">
                  <button class="cta-contact">

                      <a href="like.php">
                          <img src="heart+like+love+valentine+icon-1320084901929215407_256.png"
                              width="20px" height="20px">
                      </a>
                  </button>

                  <button class="cta-contact">

                      <a href="cart.php">
                          <img src="cart.png" width="20px" height="20px">
                      </a>
                  </button>
                  <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }
          ?>
              </div>
  </div>
  </nav>
  </header>
  </div>

    <section class="u-clearfix u-custom-color-1 u-section-1" id="sec-1d4d">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h2 class="u-align-center u-text u-text-default u-text-1"><span class="u-icon u-icon-1"><svg class="u-svg-content" viewBox="0 0 504.123 504.123" x="0px" y="0px" style="width: 1em; height: 1em;"><path style="fill:#A86A3F;" d="M39.385,83h393.846c21.662,0,39.385,17.723,39.385,39.385v47.262  c0,21.662-17.723,39.385-39.385,39.385H39.385C17.723,209.03,0,191.307,0,169.646v-47.262C0,100.723,17.723,83,39.385,83z"></path><path style="fill:#3DB39E;" d="M125.637,125.141l246.548-65.378c8.271-2.363,16.935,2.757,19.298,11.028l40.96,151.237  c2.363,8.271-2.757,16.935-11.028,19.298L100.431,326.79c-8.271,2.363-16.935-2.757-19.298-11.028L51.2,204.698L125.637,125.141z"></path><path style="fill:#78CABB;" d="M389.514,217.301l-53.169,14.178c-4.332,1.182-8.665-1.182-9.452-5.514  c-1.182-4.332,1.182-8.665,5.514-9.452l45.686-12.209l-24.418-91.372l-45.686,12.209c-4.332,1.182-8.665-1.182-9.452-5.514  c-1.182-4.332,1.182-8.665,5.514-9.452l53.169-14.178c4.332-1.182,8.665,1.182,9.452,5.514l28.357,106.338  C396.209,212.181,393.846,216.513,389.514,217.301z M168.96,276.772l-53.169,14.178c-4.332,1.182-8.665-1.182-9.452-5.514  L77.982,179.098c-1.182-4.332,1.182-8.665,5.514-9.452l53.169-14.178c4.332-1.182,8.665,1.182,9.452,5.514  c1.182,4.332-1.182,8.665-5.514,9.452l-45.686,12.209l24.418,91.372l45.686-12.209c4.332-1.182,8.665,1.182,9.452,5.514  C175.655,271.258,173.292,275.59,168.96,276.772z"></path><path style="fill:#5ABEAC;" d="M3.151,180.28C73.255,140.107,262.302,29.436,262.302,29.436c7.483-4.332,17.329-1.969,21.662,5.514  l78.769,135.483c4.332,7.483,1.575,16.935-5.908,21.268L68.529,357.116c-7.483,4.332-17.329,1.969-21.662-5.514  c0,0-22.055-44.898-44.111-82.708C2.757,180.28,3.151,209.424,3.151,180.28z"></path><path style="fill:#8CD2C5;" d="M322.56,166.101L267.422,70.79c-2.363-3.938-7.089-5.12-10.634-2.757l-47.655,27.569  c-3.938,2.363-5.12,7.089-2.757,10.634c2.363,3.938,7.089,5.12,10.634,2.757l40.96-23.631l47.262,81.92l-40.96,23.631  c-3.938,2.363-5.12,7.089-2.757,10.634c2.363,3.938,7.089,5.12,10.634,2.757l47.655-27.569  C323.348,174.766,324.923,170.04,322.56,166.101z M113.822,277.56l-40.96,23.631L25.6,219.27l40.96-23.631  c3.938-2.363,5.12-7.089,2.757-10.634c-2.363-3.938-7.089-5.12-10.634-2.757l-47.655,27.569c-3.938,2.363-5.12,7.089-2.757,10.634  l55.138,95.311c2.363,3.938,7.089,5.12,10.634,2.757l47.655-27.569c3.938-2.363,5.12-7.089,2.757-10.634  C122.486,276.772,117.76,275.196,113.822,277.56z M133.908,138.532c-30.326,17.329-40.566,55.926-23.237,86.252  c17.723,30.326,55.926,40.566,86.252,23.237s40.566-55.926,23.237-86.252C202.437,131.836,164.234,121.203,133.908,138.532z   M322.56,166.101L267.422,70.79c-2.363-3.938-7.089-5.12-10.634-2.757l-47.655,27.569c-3.938,2.363-5.12,7.089-2.757,10.634  c2.363,3.938,7.089,5.12,10.634,2.757l40.96-23.631l47.262,81.92l-40.96,23.631c-3.938,2.363-5.12,7.089-2.757,10.634  c2.363,3.938,7.089,5.12,10.634,2.757l47.655-27.569C323.348,174.766,324.923,170.04,322.56,166.101z M113.822,277.56l-40.96,23.631  L25.6,219.27l40.96-23.631c3.938-2.363,5.12-7.089,2.757-10.634c-2.363-3.938-7.089-5.12-10.634-2.757l-47.655,27.569  c-3.938,2.363-5.12,7.089-2.757,10.634l55.138,95.311c2.363,3.938,7.089,5.12,10.634,2.757l47.655-27.569  c3.938-2.363,5.12-7.089,2.757-10.634C122.486,276.772,117.76,275.196,113.822,277.56z M133.908,138.532  c-30.326,17.329-40.566,55.926-23.237,86.252c17.723,30.326,55.926,40.566,86.252,23.237s40.566-55.926,23.237-86.252  C202.437,131.836,164.234,121.203,133.908,138.532z"></path><path style="fill:#C47E4D;" d="M448.985,476.846h-409.6C17.723,476.846,0,459.123,0,437.461V153.892h448.985  c21.662,0,39.385,17.723,39.385,39.385v244.185C488.369,459.123,470.646,476.846,448.985,476.846z M31.508,153.892H0v-31.508  C0,139.713,14.178,153.892,31.508,153.892z"></path><path style="fill:#A86A3F;" d="M488.369,378.384h-63.015c-30.326,0-55.138-24.812-55.138-55.138s24.812-55.138,55.138-55.138h63.015  c8.665,0,15.754,7.089,15.754,15.754v78.769C504.123,371.295,497.034,378.384,488.369,378.384z"></path><path style="fill:#EFC75E;" d="M425.354,291.738c17.329,0,31.508,14.178,31.508,31.508s-14.178,31.508-31.508,31.508  c-17.329,0-31.508-14.178-31.508-31.508S408.025,291.738,425.354,291.738z"></path><path style="fill:#D7B354;" d="M433.231,346.876c-17.329,0-31.508-14.178-31.508-31.508c0-6.695,1.969-12.997,5.514-18.117  c-8.271,5.514-13.391,14.966-13.391,25.994c0,17.329,14.178,31.508,31.508,31.508c10.634,0,20.086-5.514,25.994-13.391  C446.228,344.907,439.926,346.876,433.231,346.876z"></path><path style="fill:#B27245;" d="M448.985,461.092h-409.6C17.723,461.092,0,443.369,0,421.707v15.754  c0,21.662,17.723,39.385,39.385,39.385h409.6c21.662,0,39.385-17.723,39.385-39.385v-15.754  C488.369,443.369,470.646,461.092,448.985,461.092z"></path><path style="fill:#CA8B5F;" d="M448.985,153.892H31.508C14.178,153.892,0,139.713,0,122.384v15.754  c0,17.329,14.178,31.508,31.508,31.508h417.477c21.662,0,39.385,17.723,39.385,39.385v-15.754  C488.369,171.615,470.646,153.892,448.985,153.892z"></path></svg><img></span>&nbsp;<span class="u-text-custom-color-3">My</span>&nbsp;<span class="u-text-custom-color-3">Wallet</span>
        </h2>
        <div class="u-align-center u-table u-table-responsive u-table-1">
          <table class="u-table-entity">
            <colgroup>
              <col width="100%">
            </colgroup>
            <tbody class="u-table-body">
              <tr style="height: 59px;">
                <td class="u-border-1 u-border-grey-dark-1 u-custom-color-3 u-table-cell u-table-cell-1">Current Wallet Balance</td>
              </tr>
              <tr style="height: 73px;">
                <td class="u-border-1 u-border-custom-color-3 u-table-cell u-table-cell-2">50000$</td>
              </tr>
            </tbody>
          </table>
        </div>
        <a href="Charge-the-wallet.html" data-page-id="732420097" class="u-border-none u-btn u-btn-round u-button-style u-custom-color-3 u-hover-palette-1-light-1 u-radius-50 u-btn-1">Charge the wallet</a>
      </div>
    </section>
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa"><div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with love by Umm Al-Qura University CS students in Internet applications course</p>
    </div></footer> 
  </body>
</html>