<!DOCTYPE html>
<html lang="en">
<body>
<?php 
    ini_set('display errors',1);
    error_reporting (E_ALL & ~E_NOTICE);

    if ($dbc =  @mysqli_connect ('localhost', 'root', '')) {

        //create ala_una scheema
        if (@mysqli_query ($dbc,'CREATE DATABASE IF NOT EXISTS ala_una')) {
            
            //select ala_una DB
            if(@mysqli_select_db($dbc,'ala_una')){
                //create query for create user table in ala_una DB
                $query1 ='CREATE TABLE IF NOT EXISTS user ( 
                    USER_ID_ INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                    NAME_ VARCHAR(20) NOT NULL,
                    EMAIL VARCHAR(20) NOT NULL,
                    PASSWORD_ VARCHAR(20) NOT NULL
                    )';
    
                //execute query  ..  insert the colomns   ..  this is the (if) mother that have all queries
                if(mysqli_query($dbc,$query1)){
    
    
                        //if user clicks sign up
                        if (isset($_POST['submit'])){
                            //create query for insert user info that is user input
                            $ins_query ="INSERT INTO user(USER_ID_,NAME_,EMAIL,PASSWORD_)
                            VALUES(0,'{$_POST['name_us']}','{$_POST['emauil_us']}','{$_POST['pass_us']}');";
                            if(@mysqli_query($dbc,$ins_query)){
                                session_start();
                                $_SESSION['username']=$_POST['name_us'];
                                // print "'{$_SESSION['username']}'";
                            }
                            else{
                                print "<p>Could not add the user information because: <b>" . mysqli_error($dbc) . "</b>. The query was $ins_query.</p>";
                            }
                        }
						//sign in
						else if(isset($_POST['submit2'])){
                            $emauil_us = $_POST['emauil_us'];
                            $pass_us = $_POST['pass_us'];
							$name = "SELECT NAME_ FROM user WHERE EMAIL='$emauil_us' AND PASSWORD_='$pass_us'";
							 
                            $query = "SELECT * FROM user WHERE EMAIL='$emauil_us' AND PASSWORD_='$pass_us'";
							$result=mysqli_query($dbc, $query);
                            if(mysqli_num_rows($result)==1)
							{
								// session_start();
                                // $_SESSION['username']=$name;
                                if($array=mysqli_query($dbc,$name)){
                                    while($row=mysqli_fetch_array($array)){
                                        session_start();
                                         $_SESSION['username']=$row['NAME_'];
                                         header('Location: Home.php');
                                        // print"HELLO {$row['NAME_']}";
                                    }}

								// header('Location: profile.php');
							}
                            
							if(isset($_POST['remember'])){
                                setcookie('emauil_us',$emauil_us,time() + (60*60*24));
                                setcookie('pass_us',$pass_us,time() + (60*60*24));
                            }
                            else{
                                setcookie('emauil_us','',time() - (60*60*24));
                                setcookie('pass_us','',time() - (60*60*24));
                            }
                                
                            
                        }
                        
                }//end of the mother (if)
    
                //error with creating employee table  .. stop exe
                else{
                    die ('<p>Could not create the table because: <b>' . mysqli_error($dbc) . '</b></p>');
                }       
            }
            //error with selecting ala_una  .. stop exe
            else{
                die ('<p>Could not select the database because: <b>' . mysqli_error($dbc) . '</b></p>');
            }
        } 
        //error with creating ala_una  .. stop exe
        else {		
            die ('<p>Could not create the database because: <b>' . mysqli_error($dbc) . '</b></p>');	
        }		
            
            mysqli_close($dbc); // Close the connection.
    } 
    else {	
        die ('<p>Could not connect to MySQL because: <b>' . mysqli_error($dbc) . '</b></p>');
    }   
    ?>
    <?php 
    //AND !isset($_POST['out'])
    function sign_in(){
        session_start(); 
        if($_SESSION['username']){
        print "Hello {$_SESSION['username']}";
        }else{
                print"sign in";
        }
    }
    function log_out(){
    session_start();
       unset($_SESSION);
        // session_id('');
        header("location:Home.php");               
        if(session_destroy()){
            print"yeah";
        }
       else{
            print"oops";
        }
    }
                    ?>
</body>
</html>