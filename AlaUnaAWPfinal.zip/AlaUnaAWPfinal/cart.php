<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <script type="text/javaScript" src="cart.js" ></script>
    <link rel="stylesheet" href="catr.css">
    <link rel="stylesheet" href="nicepage.css" media="screen">
    <link rel="stylesheet" href="menu.css">
    <link rel="stylesheet" href="menu.css">
  <link id="u-theme-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
  <link id="u-page-google-font" rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i">
<style>
  section{
    margin-left: 100px;
    margin-right: 100px;
  }
</style>
</head>
<body>
<?php
 require('loginAWP.php');
?>
<!-- 
cart

https://codepen.io/bartveneman/pen/KHxLG

-->

  <div class="wrapper">
    <header class="page-header">
      <nav>
        <a href="Home.php" class="logo"><img src="the_foodies_place-removebg-preview.png" width="120px" height="120px">
        </a>
        <ul>
          <li class="dropdown">
            <a class="dropbtn"> New </a>
            <div class="dropdown-content">
              <a href="vintage-musical-instruments.php">vintage musical instruments</a>
              <a href="vintage-art-painting.php">vintage art painting</a>
              <a href="antiques.php">antiques</a>
              <a href="limited-musical-instruments.php">limited edition musical instruments</a>
              <a href="limited-art-painting.php">limited edition art painting</a>
              <a href="limited-pieces.php">limited edition pieces</a>
            </div>
          </li>
          <li>
            <a href="Add-Pieces.php"> Add Piece </a>
          </li>

          <li>
            <a href="about-us.php">About us </a>
          </li>
        </ul>
        <div class="cta-contact_2">
          <button class="cta-contact">

            <a href="like.php">
              <img src="heart+like+love+valentine+icon-1320084901929215407_256.png" width="20px" height="20px">
            </a>
          </button>

          <button class="cta-contact">

            <a href="cart.php">
              <img src="cart.png" width="20px" height="20px">
            </a>
          </button>
          <button class="cta-contact"> <a href="signin.php"><?php  sign_in(); ?></a>
          </button>
          <?php
          if($_SESSION['username']){
          print"<a class='cta-contact' href='logout.php'> log out </a>";
        }
          ?>
        </div>
  </div>
  </nav>
  </header>
  </div>
    <div class="main">
        <h1>Shopping cart</h1>
        <h2 class="sub-heading">Free shipping from $100!</h2>
      <section>      
          <footer class="_grid cart-totals">
            <div class="_column subtotal" id="subtotalCtr">
              <div class="cart-totals-key">Subtotal</div>
              <div class="cart-totals-value">$0.00</div>
            </div>
            <div class="_column shipping" id="shippingCtr">
              <div class="cart-totals-key">Shipping</div>
              <div class="cart-totals-value">$0.00</div>
            </div>
            <div class="_column taxes" id="taxesCtr">
              <div class="cart-totals-key">Taxes (6%)</div>
              <div class="cart-totals-value">$0.00</div>
            </div>
            <div class="_column total" id="totalCtr">
              <div class="cart-totals-key">Total</div>
              <div class="cart-totals-value">$0.00</div>
            </div>
            <div class="_column checkout">
              <button class="_btn checkout-btn entypo-forward">Checkout</button>
            </div>
      
        </section>
      </div>
    </br> 
  </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> </br> 
  <footer class="u-align-center u-clearfix u-footer u-grey-50 u-footer" id="sec-e7aa">
    <div class="u-clearfix u-sheet u-sheet-1">
      <p class="u-small-text u-text u-text-variant u-text-1"> © Copyright 2021. All rights reserved. </br> Made with
        love by Umm Al-Qura University CS students in Internet applications course</p>
    </div>
  </footer>

     
</body>
</html>